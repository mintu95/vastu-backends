# vastu-backends
Vastu AI backend in Flask
